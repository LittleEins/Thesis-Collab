import csv
with open('AttendanceReport.csv', 'r') as file:
    csv_Reader = csv.reader(file)
    for row in csv_Reader:
        print(row)
