import csv

with open('attendanceReport.csv', 'r') as file:
    reader = csv.reader(file)
    for row in reader:
        print(row)
